<!DOCTYPE html>
<html>
	<head>
	  <?php 
        include 'header.php';	  
	  ?>
	</head>
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
          <?php 
            include 'menubar.php';
        ?>
		</div>
	</div>
	
<?php 
//update user information
include 'dbh.php';

if(isset($_POST['update'])){
    
    $name = mysqli_real_escape_string($conn, $_POST['update_name']);
    $age = mysqli_real_escape_string($conn,$_POST['update_age']);
    $username = mysqli_real_escape_string($conn, $_POST['update_username']);
    $email = mysqli_real_escape_string($conn, $_POST['update_email']);
    $occupation = mysqli_real_escape_string($conn,$_POST['update_occupation']);
    $pwd = mysqli_real_escape_string($conn, $_POST['update_password']);
    $cpwd=$_POST['update_confirmpassword'];
    
    if(empty($name) || empty($age) || empty($username) || empty($email) || empty($occupation)) {
        echo "Update failed! Your input is empty";
        exit();
        
    }elseif(!preg_match("/^[a-zA-Z .]*$/", $name)){
        echo "Your Name must contains only letters and white space";
        exit();
        
    }elseif(!preg_match("/^[0-9]{1,5}$/", $age)){
        echo "Invalid Age";
        exit();
           
    }elseif(!preg_match("/^[a-zA-Z0-9 ]*$/", $username)){
        echo "Your username must contains only letters and/or numbers";
        exit();
        
    }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo "Invalid email format";
        exit();
   
    }elseif(!preg_match("/^[a-zA-Z ]*$/", $occupation)){
        echo "Your occupation must contains only letters and white space";
        exit();
        
    }
    
    
    //**
    $sql="SELECT * FROM donor WHERE donorusername=?;";
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt,$sql)){
        echo "SQL statement failed";
    }else{
        mysqli_stmt_bind_param($stmt, "s" ,$username);
        mysqli_stmt_execute($stmt);
        $result=mysqli_stmt_get_result($stmt);
    }
    
    $resultCheck= mysqli_num_rows($result);
    
    //check if user exist
    if($resultCheck>1){
        echo "User name has been taken.";
        exit();
    }
    
    if(!empty($pwd)){
        
        $hashedPwd=password_hash($pwd, PASSWORD_DEFAULT);
        $sql="UPDATE donor SET donorname=?,donorage=?,donorusername=?,donoremail=?,donorpassword=?,
          occupation=? WHERE donorusername='$_POST[username]';";
        
        $stmt=mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            echo "SQL error";
        }else{
            mysqli_stmt_bind_param($stmt, "sissss",$name,$age,$username,$email,$hashedPwd,$occupation);
            mysqli_stmt_execute($stmt);
        }
    }else{
       $sql="UPDATE donor SET donorname=?,donorage=?,donorusername=?,donoremail=?,donorpassword=?,
          occupation=? WHERE donorusername='$_POST[username]';";
        
        $stmt=mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            echo "SQL error";
        }else{
            mysqli_stmt_bind_param($stmt, "sissss",$name,$age,$username,$email,$hashedPwd,$occupation);
            mysqli_stmt_execute($stmt);
        }
    }
  
         
    if(mysqli_stmt_prepare($stmt,$sql)){
        
        $_SESSION['d_newname']=$name;
        $_SESSION['d_newage']=$age;
        $_SESSION['d_newusername']=$username;
        $_SESSION['d_newemail']=$email;
        $_SESSION['d_newoccupation']=$occupation;
        
        echo "<h4 style='text-align:left; padding-left:20px; color:green;'> Update Successful!</h4>";
       ?>
       	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-0">
		</div>
		
		<div class="col-lg-6 col-md-6 col-sm-8 col-xs-12">
        <table style="border:1px solid #cccccc;" class="table table-user-information">
        <tbody>
        <tr>
        <th style="font-size:18px;" >Updated Personal Information</th>
        <th></th>
        </tr>
        
        <tr>
        	<td>Full Name:</td>
        	<td><?php echo $_SESSION['d_newname']?></td>
        </tr>
            
        <tr>
        	<td>Student Age:</td>
        	<td><?php echo $_SESSION['d_newage']?></td>
        </tr>
        
        <tr>
        	<td>User Name:</td>
            <td><?php echo $_SESSION['d_newusername']?></td>
        </tr>
        
        <tr>
        	<td>Email:</td>
        	<td><?php echo $_SESSION['d_newemail']?></td>
        </tr>
                
        <tr>
            <td>Occupation:</td>
            <td><?php echo $_SESSION['d_newoccupation']?></td>
        </tr>
        

      </tbody>
      </table>
      
      <form action="index.php">
		    <button type="submit" name="backtohome" style="float:right; margin-top:5px;" class="btn btn-default">DONE</button>
	  </form>
       
      
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-0">
		</div>
	    </div>
        </div>
       <?php 
    }else{
        echo "Update failed";
    }
}

?>




   <div class="row" style="padding-top:100px;">    
    <?php 
    include "footer.php";
    ?>
    </div>

</body>
</html>