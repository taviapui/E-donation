<?php 
require 'PHPMailerAutoload.php';

$mail = new PHPMailer(true);
//check if the form is submit

if(isset($_POST['submit'])){
    try {
        $name=$_POST['name'];
        $emailFrom=$_POST['email'];
        $subject=$_POST['subject'];
        $message=$_POST['message'];
        

        $mail ->isSMTP();
        $mail ->SMTPDebug = 0;
        $mail ->SMTPAuth = true;
        $mail ->SMTPSecure = 'tls';
        $mail ->Host = "smtp.gmail.com";
        $mail ->Port = 587;
        $mail ->isHTML(true);
        $mail ->Username = "smvision2019@gmail.com";
        $mail ->Password = "smvision123";
        
        $mail ->setFrom("smvision2019@gmail.com");
        // $mail ->addReplyTo($emailFrom);
        $mail ->Subject = $subject;
        $mail ->Body = $message;
        $mail ->AddAddress('smvision2019@gmail.com');
        
        $mail ->send();
        
        
        ?>
    <!DOCTYPE html>
	<html>
    <?php 
       include 'header.php'
    ?>
    <body>
        
            
          
        <div class="row">
            <div class="navbar-wrapper">
              <?php 
                include 'menubar.php';
            ?>
            </div>
        </div>
<!-- /navigation bar -->	

        <div class="row" style="padding-left:15px;">
		   <form action="index.php">
		   	 	<h4 style="color:green;">Your Email has been submmited!</h4>
		       <button type="submit" name="backtohome" class="btn btn-default">Back To Home Page</button>
		   </form>
        </div>';
        <?php 
    } catch (Exception $e) {
        echo 'E-mail could not be sent.';
        echo 'Mailer Error: '.$mail->ErrorInfo;
    }
}
   

?>