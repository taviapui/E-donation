<div class="row" style="margin-top:-20px; ">
    <div class="py-5 bg-image-full full-width-image-container">
    	<a href="#goToDonationPanels"><img src="pictures/image1.jpg" class="image-panel"/></a>
    	<a href="#goToDonationPanels" type="button" class="btn btn-info"><b>Donate Now</b></a>
    </div>
</div>
<a id="goToDonationPanels"></a> 
