<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'menubar.php';
            ?>
		</div>
	</div>

 <?php
 
 
 $donorNameErr=$donorAgeErr=$donorUsernameErr=$donorPasswordErr=$donorConfirmPasswordErr=$donorEmailErr=$donorOccupationErr="";
 $donorName=$donortAge=$donorUsername=$donorPassword=$donorConfirmPassword=$donorEmail=$donorOccupation="";
 $errorfound=false;
 
 if($_SERVER["REQUEST_METHOD"]=="POST"){
// if (isset($_POST['submit'])) {
     if(empty($_POST["reg_donor_name"])){
         $donorNameErr="Name is required"; 
         $errorfound = true; 
     }else{
         $donorName=test_input($_POST["reg_donor_name"]);
         if(!preg_match("/^[a-zA-Z ]*$/", $donorName)){
            $donorNameErr="Only letters and white space allowed";
         }                    
     }
     
     if(empty($_POST["reg_donor_age"])){
         $donorAgeErr="Age is required";
         $errorfound=true;
     }else{
         $donorAge=test_input($_POST["reg_donor_age"]);
         if(!preg_match("/^[0-9]+$/",$donorAge)){
             $donorAgeErr="Please insert a valid age!";
         }
     }
     
     if(empty($_POST["reg_donor_username"])){
         $donorUsernameErr="User Name is required";
         $errorfound=true;
     }else{
         $donorUsername=test_input($_POST["reg_donor_username"]);
         if(!preg_match("/^[a-zA-Z0-9]*$/",$donorUsername)){
             $donorUsernameErr="Only letters and numbers allowed";
         }
     }
     
     if(empty($_POST["reg_donor_password"])){
         $donorPasswordErr="Password is required";
         $errorfound=true;
     }else{
         $donorPassword=$_POST["reg_donor_password"];
         
     }
     
     if(empty($_POST["reg_donor_password_confirm"])){
         $donorConfirmPasswordErr="Password Confirmation is required";
     }else{
         if($_POST["reg_donor_password_confirm"]==$donorPassword){
             $donorConfirmPassword=$_POST["reg_donor_password_confirm"];
         }else{
             $donorConfirmPasswordErr= "Your password does not match";
         }
     }
     
     if(empty($_POST["reg_donor_email"])){
         $donorEmailErr="Email is required";
         $errorfound=true;
     }else{
         $donorEmail=test_input($_POST["reg_donor_email"]);
         if(!filter_var($donorEmail,FILTER_VALIDATE_EMAIL)){
             $donorEmailErr="Invalid email format";
         }
     }
     
     if(empty($_POST["reg_donor_occupation"])){
         $donorOccupation = ""; 
     }else{
         $donorOccupation=test_input($_POST["reg_donor_occupation"]);
         if(!preg_match("/^[a-zA-Z -]{4,20}$/",$donorOccupation)){
             $donorOccupationErr="Only letters are allowed";
         }
     }
     
 }
 
 
 
 function test_input($data){
     $data=trim($data);
     $data=stripslashes($data);
     $data=htmlspecialchars($data);
     return $data;
 }
 
  
 if ($errorfound==false){
     if(isset($_POST['submit'])){
         include_once 'dbh.php';
         
         $name = mysqli_real_escape_string($conn, $_POST['reg_donor_name']);
         $age = mysqli_real_escape_string($conn, $_POST['reg_donor_age']);
         $userName = mysqli_real_escape_string($conn, $_POST['reg_donor_username']);
         $pwd = mysqli_real_escape_string($conn, $_POST['reg_donor_password']);
         $email = mysqli_real_escape_string($conn, $_POST['reg_donor_email']);
         $occupation = mysqli_real_escape_string($conn, $_POST['reg_donor_occupation']);
         
         $sql="SELECT * FROM donor WHERE donoremail=?;";
         $stmt=mysqli_stmt_init($conn);
         
         if(!mysqli_stmt_prepare($stmt, $sql)){
             echo "SQL statement failed";
         }else{
             mysqli_stmt_bind_param($stmt, "s",$email);
             mysqli_stmt_execute($stmt);
             $result=mysqli_stmt_get_result($stmt);
         }
         
         $resultCheck= mysqli_num_rows($result);
         
         //check if user exist
         if($resultCheck>0){
             
             echo "You have been registered or user name has been taken.";
             exit();
         }else{
             //hash password for security
             $hashedPwd=password_hash($pwd, PASSWORD_DEFAULT);
             
             //insert user data into database
             $sql="INSERT INTO donor(donorname, donorusername, donorpassword, donorage, donoremail, occupation)
                  VALUES(?,?,?,?,?,?);";
             $stmt=mysqli_stmt_init($conn);
             if(!mysqli_stmt_prepare($stmt, $sql)){
                 echo "SQL statement error";
             }else{
                 mysqli_stmt_bind_param($stmt, "sssiss",$name, $userName, $hashedPwd, $age, $email, $occupation); 
                 mysqli_stmt_execute($stmt);
                 header('location:donorLoginForm.php');
                 exit();
             }
         }
         
     }
 }
 
 
?>



	<div class="container">
	  <div class="row">
	  <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
  	  	<h2>Donor Registration Form</h2>
  	  </div>
  	  <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  <div class="row">
		<div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
			
			<div class="form-group">
				<label for="reg-donor-name">Donor Name:</label><span class="error">*<?php echo $donorNameErr;?></span>
				<input type="text" class="form-control" id="reg_donor_full_name" placeholder="Enter Your Name..." name="reg_donor_name">
			</div>
			
			<div class="form-group">
				<label for="reg-donor-age">Donor Age:</label><span class="error">*<?php echo $donorAgeErr;?></span>
				<input type="text" class="form-control" id="reg_donor_age" name="reg_donor_age" placeholder="Enter Your Age...">
			</div>
			
			<div class="form-group">
				<label for="reg-donor-username">User Name:</label><span class="error">*<?php echo $donorUsernameErr;?></span>
				<input type="text" class="form-control" id="reg_donor_username" name="reg_donor_username" placeholder="Enter username...">
			</div>
			
			<div class="form-group">
				<label for="reg-donor-password">Password:</label><span class="error">*<?php echo $donorPasswordErr;?></span>
				<input type="password" class="form-control" id="reg_donor_password" name="reg_donor_password" placeholder="Enter Password...">
			</div>
			
			<div class="form-group">
				<label for="reg-donor-password-confirm">Confirm Password:</label><span class="error">*<?php echo $donorConfirmPasswordErr;?></span>
				<input type="password" class="form-control" id="reg_donor_password_confirm" name="reg_donor_password_confirm" placeholder="Confirm Password...">
			</div>
		
			<div class="form-group">
				<label for="reg-donor-email">Donor Email:</label><span class="error">*<?php echo $donorEmailErr;?></span>
				<input type="email" class="form-control" id="reg_donor_email" placeholder="Enter email..." name="reg_donor_email">
			</div>
			
			 <div class="form-group">
				<label for="reg-donor-occupation">Donor Occupation:</label><span class="error"><?php echo $donorOccupationErr;?></span>
				<input type="text" class="form-control" id="reg_donor_occupation" name="reg_donor_occupation" placeholder="Enter Your Occupation...">
			</div>
		
			<button type="submit" name="submit" class="btn btn-default">Register</button>
			
			<div class="etc-login-form">
				<p>already have an account? <a href="donorloginform.php">login here</a></p>
			</div>
		</form>
		</div>
		<div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>
	</div>
	
	<br><br><br><br><br><br><br>
	<?php 
    include "footer.php";
    ?>
	
	</body>
</html>

	
