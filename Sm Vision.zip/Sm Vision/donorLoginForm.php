<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'menubar.php';
            ?>
		</div>
	</div>


   
<?php 
$nameErr=$passwordErr="";
$name=$password="";
$errorfound=false;

if($_SERVER["REQUEST_METHOD"]=="POST"){
    
    if(empty($_POST["log_name"])){
        $nameErr="User Name or Email is required";
        $errorfound=true;
    }else{
        $name=test_input($_POST["log_name"]);
    }
    
 
    if(empty($_POST["log_password"])){
        $passwordErr="Password is required";
        $errorfound=true;
    }else{
        $password=$_POST["log_password"];
    }
    
   
}


function test_input($data){
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}


if ($errorfound==false){
    
    if(isset($_POST['submit'])){
        
        include_once 'dbh.php';
        
        $log=mysqli_real_escape_string($conn,$_POST['log_name']);
        $pwd=mysqli_real_escape_string($conn,$_POST['log_password']);
        
        //user_uid or user_email query use in order for user to log in using email or username 
        $sql="SELECT * FROM donor WHERE donorusername=? OR donoremail=?;";
        //use prepared statement 
        $stmt=mysqli_stmt_init($conn);
        
        if(!mysqli_stmt_prepare($stmt, $sql)){
            echo "SQL statement failed";
        }else{
            mysqli_stmt_bind_param($stmt, "ss", $log, $log);
            mysqli_stmt_execute($stmt);
            $result=mysqli_stmt_get_result($stmt);    
        }
        
        //assign the result to mysqli_num_rows to check the number of result 
        $resultCheck=mysqli_num_rows($result);
        
        //if username or email not exist in database 
        if($resultCheck<1){
            echo "Your log in failed.";
            exit();
        }else{
            //if username or email exist in database 
            if($row=mysqli_fetch_assoc($result)){
                //dehashed the password
                //Verifies that a password matches a hash (password_verify use to dehash password) 
                $hashedPwdCheck=password_verify($pwd,$row['donorpassword']);
                //if password not matches a hash 
                if($hashedPwdCheck==false){
                    echo "Your password is incorrect.";
                    exit();
                  //if password matches a hash 
                }elseif($hashedPwdCheck==true){
                    //log in user 
                    // assign user data in database into each sessions 
                    $_SESSION['d_name']=$row['donorname'];
                    $_SESSION['d_username']=$row['donorusername'];
                    $_SESSION['d_age']=$row['donorage'];
                    $_SESSION['d_email']=$row['donoremail'];
                    $_SESSION['d_occupation']=$row['occupation'];
                    
                    
                    header('location:index.php');
                    exit;
                    exit();
                }
            }
        }
        
            
    }
}

?>
      

  
<?php 
//if user is not log in 
    if(!(isset($_SESSION['d_username']))){
    ?>
	    <div class="container">
    		<div class="row">
    			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
    			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    				<h2 class="log-in-title">Donor Log In</h2>
    			</div>		
    			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
    		</div>	
    		<div class="row">    
        		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
        		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
            			<div class="form-group">
            				<label for="log-name">User Name:</label><span class="error"><?php echo $nameErr?></span>
            				<input type="text" class="form-control" id="log_name" name="log_name" placeholder="Enter username or email...">
            			</div>
            			<div class="form-group">
            				<label for="log-password">Password:</label><span class="error"><?php echo $passwordErr?></span>
            				<input type="password" class="form-control" id="log_password" name="log_password" placeholder="Enter Password...">
            			</div>
            			
            			<button type="submit" name="submit" class="btn btn-default">Log In</button>
            			
            			<div class="etc-login-form">
            				<p>New User? <a href="donorRegistrationForm.php">Create New Account</a></p>
            			</div>
            		</form>
        		</div>
    			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"></div>
    		</div>
		</div>
	<?php 
	
    }else{
        ?>
        
        <!-- after user log in -->
        
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
		
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<form action="donorinformationupdate.php" method="POST">
        <table style="border:1px solid #cccccc;" class="table table-user-information">
          <tbody>
                  <tr>
                  <th style="font-size:25px; font-family:arial; color:#A4A4A4" >Personal Information</th>
                  <th></th>
                  </tr>
                  
                  <tr>
                    <td style="color:#6E6E6E">Full name:</td>
                    <td><input type="text" name="update_name" 
                        value="<?php
                        if(isset($_SESSION['d_newname'])){
                            echo $_SESSION['d_newname'];
                        }else{
                            echo $_SESSION['d_name'];
                        }
                        ?>" />
                    </td>
                  </tr>
                  
                  <tr>
                    <td style="color:#6E6E6E">Donor Age:</td>
                    <td><input type="text" name="update_age" 
                        value="<?php
                        if(isset($_SESSION['d_newage'])){
                            echo $_SESSION['d_newage'];
                        }else{
                            echo $_SESSION['d_age'];
                        }
                        ?>" />
                    </td>
                  </tr>
                  
                  <tr>
                    <td style="color:#6E6E6E">User Name:</td>
                    <td><input type="text" name="update_username" 
                        value="<?php
                        if(isset($_SESSION['d_newusername'])){
                            echo $_SESSION['d_newusername'];
                        }else{
                            echo $_SESSION['d_username'];
                        }
                        ?>" />
                    </td>
                  </tr>

                  <tr>
                    <td style="color:#6E6E6E">Email:</td>
                    <td><input type="text" name="update_email" 
                        value="<?php
                        if(isset($_SESSION['d_newemail'])){
                            echo $_SESSION['d_newemail'];
                        }else{
                            echo $_SESSION['d_email'];
                        }
                        ?>" />
                    </td>
                  </tr>
	
                  <tr>
                    <td style="color:#6E6E6E">Occupation:</td>
                    <td><input type="text" name="update_occupation" 
                        value="<?php
                        if(isset($_SESSION['d_newoccupation'])){
                            echo $_SESSION['d_newoccupation'];
                        }else{
                            echo $_SESSION['d_occupation'];
                        }
                        ?>" />
                    </td>
                  </tr>

                  
                  <tr>
                    <td style="color:#6E6E6E">New Password *(leave this field empty if not needed):</td>
                    <td><input type="password" name="update_password" 
                        value="" />
                    </td>
                  </tr>
                  
                  <tr>
                    <td style="color:#6E6E6E">Confirm Password *(leave this field empty if not needed):</td>
                    <td><input type="password" name="update_confirmpassword" 
                        value="" />
                    </td>
                  </tr>
                  
               </tbody>      
        </table>
         
        <input type="hidden" name="username" value="<?php echo $_SESSION['d_username']?>" />
        <button type="submit" name="update" style="float:right; margin-top:5px;" class="btn btn-default">Save Changes</button>
		</form>  
        </div>
           
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
  
        <?php 
    }//end else
?>

    <div class="row" style="padding-top:700px;">    
    <?php 
    include "footer.php";
    ?>
    </div>


</body>
</html>
