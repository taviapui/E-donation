<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php';
	   
	?>
	  <!--  <link rel="stylesheet" href="searchfield.css"> -->
	
<body>
	
<div class="row">
	<div class="navbar-wrapper">
        <?php 
            include 'menubar.php';
        ?>
	</div>
</div>

<div class="container" style="border:1px solid lightGrey; margin-bottom:40px;">
	  <div class="row">
	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-4 col-md-8 col-sm-8 col-xs-12">
  	  	<h2 style="text-align:center;"> Donate Student </h2>
  	  </div>
  	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  
	  <div class="row">
		<div class="col-lg-1 col-md-1 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-10 col-md-10 col-sm-8 col-xs-12">
			<h3 style="text-align:justify; font-size: 22px;">The SM Vision Foundation inspires and empowers students from low-income families to
			    enroll in and graduate from postsecondary institutions of higher education, by providing the tools, 
			    knowledge, and financial resources essential for success.   </h3>
		</div>
		<div class="col-lg-1 col-md-1 col-sm-2 col-xs-0">
		</div>
	  </div>
</div>
<div class="row">
	<?php 
	   include 'searchBar.php';
	?>
</div>

<script>
	var table = document.getElementById("table"); 
	for(var i=1; i<table.rows.length; i++){
		table.rows[i].onclick=function(){
			var rIndex=this.rowIndex; 
			var name = this.cells[0].innerHTML; 
			var age = this.cells[1].innerHTML;
			var schoolName = this.cells[2].innerHTML; 
			var educationLevel = this.cells[3].innerHTML; 
			var studentID = this.cells[4].innerHTML; 
			var email = this.cells[5].innerHTML;
			var status = this.cells[6].innerHTML;
			var image = this.cells[7].innerHTML;

			document.cookie = 'name' + "=" + name;
			document.cookie = 'age' + "=" + age;
			document.cookie = 'schoolName' + "=" + schoolName;
			document.cookie = 'educationLevel' + "=" + educationLevel;
			document.cookie = 'studentID' + "=" + studentID;
			document.cookie = 'email' + "=" + email;
			document.cookie = 'status' + "=" + status;
			document.cookie = 'image' + "=" + image;

			window.location.href="studentInfo.php";
			 
		}
	}
</script>

<div class="row" style="padding-top:700px;">    
<?php 
    include "footer.php";
?>
</div>
</body>
</html>
