<!DOCTYPE html>
<html>
    <?php 
       include 'header.php'; 
    ?>
    
<body>
    
<div class="row">
    <div class="navbar-wrapper">
        <?php 
            include 'menubar.php';
        ?>
    </div>
</div>

<?php

if(isset($_SESSION['d_username'])){
    include 'dbh.php'; 
    
    ?>




    <!-- include html for payment --> 





    <div class="container">                     
                    <div id="div2" class="targetDiv">
                        <div class="main-wrapper">
                            <div class="container mt-5">
                              <div class="row">
                                <div class="col-md-6 ml-auto mr-auto">
                                  <div class="card bg-custom-1 mb-5">
                                    <h3 class="card-header">Credit Card / Visa</h3>
                                    <div class="card-body">
                                      <div class="signup_form row">
                                        <div class="col-md-12 ml-auto mr-auto">
                                          <form>

                                            <div class="form-group">
                                              <label for="amount" class="control-label" >Donation Amount</label><br>
                                               <div class="controls">
                                                  <input type="text" class="input-block-level" placeholder="Please insert amount in RM...." required>
                                                </div>
                                            </div>

                                            <div class="control-group">
                                                <label for="cardHolderName" class="control-label">Card Holder's Name</label>
                                                <div class="controls">
                                                  <input type="text" class="input-block-level" placeholder="Olease insert your name" title="Fill your first and last name" required>
                                                </div>
                                             </div><!-- control-group -->
                                              
                                              
                                            <div class="control-group">
                                                <label for="cardNumber" class="control-label">Card Number</label>
                                                <div class="controls">
                                                  <div class="row-fluid">
                                                    <div class="span3">
                                                      <input type="text" id="accNo" class="input-block-level" autocomplete="off" maxlength="4" pattern="\d{4}" placeholder="••••" title="First four digits" required>
                                                    </div>
                                                        <div class=" icon">
                                                        &#8212;
                                                        </div>
                                                    <div class="span3" style="margin: 7px";>
                                                      <input type="text" id="accNo" class="input-block-level" autocomplete="off" maxlength="4" pattern="\d{4}" placeholder="••••" title="Second four digits" required>
                                                    </div>
                                                        <div class=" icon">
                                                        &#8212;
                                                        </div>
                                                    <div class="span3">
                                                      <input type="text" id="accNo" class="input-block-level" autocomplete="off" maxlength="4" pattern="\d{4}" placeholder="••••" title="Third four digits" required>
                                                    </div>
                                                        <div class=" icon">
                                                        &#8212;
                                                        </div>
                                                    <div class="span3">
                                                      <input type="text" id="accNo" class="input-block-level" autocomplete="off" maxlength="4" pattern="\d{4}" placeholder="••••" title="Fourth four digits" required>
                                                    </div><!-- span3 -->
                                                  </div><!-- row-fluid -->
                                                </div><!-- controls -->
                                            </div><!-- control-group -->
                                             
                                           <div class='form-row'>
                                                <div class='col-xs-4 form-group cvc required' style="padding-left: 0px;">
                                                    <label for="cvc" class='control-label'>CVC</label>
                                                    <input autocomplete='off' id="accNo" class='form-control card-cvc' maxlength="3" pattern="\d{3}" placeholder='311' size='4' type='text'>
                                                </div> <!-- col-xs-4 form-group cvc required -->
                                            
                                                <div class='col-xs-4 form-group expiration required'>
                                                    <label for="expiration" class='control-label'>Expiration</label>
                                                    <input class='form-control card-expiry-month' maxlength="2" pattern="\d{2}" placeholder='MM' size='2' type='text'>
                                                </div><!-- col-xs-4 form-group expiration required -->
                                            
                                               <div class='col-xs-4 form-group expiration required'>
                                                    <label class='control-label'> </label>
                                                    <input class='form-control card-expiry-year' maxlength="4" pattern="\d{4}" placeholder='YYYY' size='4' type='text'>
                                              </div><!-- col-xs-4 form-group expiration required -->
                                           </div><!-- form-row --> 



                                            <div class="text-center">
                                                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Submit</button>
                                                <div class="modal fade" id="myModal" role="dialog">
                                                    <div class="modal-dialog modal-sm" style="width: 500px";>
                                                      <div class="modal-content">
                                                        <div class="modal-header">
                                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                          <h4 class="modal-title">Donation Successful</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>On behalf of SM Vision, I would like to thank you for your donation.</p>
                                                            <p>Our Organisation relies on the generosity of donors such as yourself and is grateful for you support.</p><br>
                                                            <p>Thank you once again and hope you have a nice day</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <div class="text-center">
                                                                <a class="btn btn-info m-t-15 m-b-15" href="index.php">Close</a>
                                                            </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                </div>
                                            </div>
 
                                         </form>    
                                        </div><!--col-md-12 ml-auto mr-auto -->
                                      </div><!-- signup_form row -->
                                    </div><!-- card-body -->
                                  </div><!-- card bg-custom-1 mb-5 -->
                                </div><!-- col-md-6 ml-auto mr-auto -->
                              </div><!-- row -->
                            </div><!-- container mt-5 -->
                
                        </div><!-- main-wrapper -->                 
                    </div><!-- targetDiv -->
                </div><!-- container -->
                
    <?php 
    //change student sponsorship status to sponsored once payment is done
    $id = $_COOKIE['studentID']; 
    $status = 'Sponsored'; 
    
    $sql = "UPDATE student SET sponsorshipStatus=? WHERE studentid=?";
    $stmt=mysqli_stmt_init($conn);
    
    if(!mysqli_stmt_prepare($stmt, $sql)){
        echo "SQL statement failed";
    }else{
        mysqli_stmt_bind_param($stmt, "ss", $status, $id);
        mysqli_stmt_execute($stmt);
        $result=mysqli_stmt_get_result($stmt);
    }
    //
}else{
    header('location:donorLoginForm.php');
    exit();
}
?>

<div class="row" style="padding-top:700px;">    
<?php 
    include "footer.php";
?>
</div>
</body>
</html>
