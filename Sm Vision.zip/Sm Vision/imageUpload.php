<!DOCTYPE html>
<html>
    <?php 
       include 'header.php'; 
    ?>
    
    <body>
        
    <div class="row">
        <div class="navbar-wrapper">
            <?php 
                include 'menubar.php';
            ?>
        </div>
    </div>

 <?php
 
 
 $studentFullNameErr=$studentAgeErr=$studentUsernameErr=$studentEmailErr=$studentPasswordErr=$studentConfirmPasswordErr=$studentSchoolErr=$studentEducationLevelErr=$studentIDErr=$studentImgErr="";
 $studentFullName=$studentAge=$studentUsername=$studentEmail=$studentPassword=$studentConfirmPassword=$studentSchool=$studentEducationLevel=$studentID="";
 $errorfound=false;
 
 if($_SERVER["REQUEST_METHOD"]=="POST"){
// if (isset($_POST['submit'])) {
     if(empty($_POST["reg_student_full_name"])){
         $studentFullNameErr="Name is required"; 
         $errorfound = true; 
     }else{
         $studentFullName=test_input($_POST["reg_student_full_name"]);
         if(!preg_match("/^[a-zA-Z ]*$/", $studentFullName)){
            $studentFullNameErr="Only letters and white space allowed";
         }                    
     }
     
     if(empty($_POST["reg_student_age"])){
         $studentAgeErr="Age is required";
         $errorfound=true;
     }else{
         $studentAge=test_input($_POST["reg_student_age"]);
         if(!preg_match("/^[0-9]+$/",$studentAge)){
             $studentAgeErr="Please insert a valid age!";
         }
     }
     
     if(empty($_POST["reg_student_username"])){
         $studentUsernameErr="User Name is required";
         $errorfound=true;
     }else{
         $studentUsername=test_input($_POST["reg_student_username"]);
         if(!preg_match("/^[a-zA-Z0-9]*$/",$studentUsername)){
             $studentUsernameErr="Only letters and numbers allowed";
         }
     }
     
     if(empty($_POST["reg_student_email"])){
         $studentEmailErr="Email is required";
         $errorfound=true;
     }else{
         $studentEmail=test_input($_POST["reg_student_email"]);
         if(!filter_var($studentEmail,FILTER_VALIDATE_EMAIL)){
             $studentEmailErr="Invalid email format";
         }
     }
     
     if(empty($_POST["reg_student_password"])){
         $studentPasswordErr="Password is required";
         $errorfound=true;
     }else{
         $studentPassword=$_POST["reg_student_password"];
         
     }
     
     if(empty($_POST["reg_student_password_confirm"])){
         $studentConfirmPasswordErr="Confirm Password is required";
     }else{
         if($_POST["reg_student_password_confirm"]==$studentPassword){
             $studentConfirmPassword=$_POST["reg_student_password_confirm"];
         }else{
             $studentConfirmPasswordErr= "Your password does not match";
         }
     }
     
     if(empty($_POST["reg_student_school"])){
         $studentSchoolErr="School name is required";
         $errorfound=true;
     }else{
         $studentSchool=test_input($_POST["reg_student_school"]);
         if(!preg_match("/^[a-zA-Z -]{4,20}$/",$studentSchool)){
             $studentSchoolErr="Only letters are allowed";
         }
     }
     
     if(empty($_POST["reg_student_education_level"])){
         $studentEducationLevelErr="Please provide your education level";
         $errorfound=true;
     }else{
         $studentEducationLevel=test_input($_POST["reg_student_education_level"]);
         if(!preg_match("/^[a-zA-Z -]{4,40}$/",$studentEducationLevel)){
             $studentEducationLevelErr="Only letters are allowed";
         }
     }
     
     if(empty($_POST["reg_student_id"])){
         $studentIDErr="Student ID is required";
         $errorfound=true;
     }else{
         $studentID=test_input($_POST["reg_student_id"]);
         if(!preg_match("/^[a-zA-Z0-9 -]+$/",$studentID)){
             $studentIDErr="Please insert a valid student ID!";
         }
     }
     
 }
 
 
 
 function test_input($data){
     $data=trim($data);
     $data=stripslashes($data);
     $data=htmlspecialchars($data);
     return $data;
 }
 
  
 if ($errorfound==false){
     if(isset($_POST['submit'])){
         include_once 'dbh.php';
         
         $fullName = mysqli_real_escape_string($conn, $_POST['reg_student_full_name']);
         $age = mysqli_real_escape_string($conn, $_POST['reg_student_age']);
         $userName = mysqli_real_escape_string($conn, $_POST['reg_student_username']);
         $email = mysqli_real_escape_string($conn, $_POST['reg_student_email']);
         $pwd = mysqli_real_escape_string($conn, $_POST['reg_student_password']);
         $school = mysqli_real_escape_string($conn, $_POST['reg_student_school']);
         $educationLevel = mysqli_real_escape_string($conn, $_POST['reg_student_education_level']);
         $studentid = mysqli_real_escape_string($conn, $_POST['reg_student_id']);

         
         $file = $_FILES['file'];
         
         $fileName = $_FILES['file']['name']; 
         $fileTmpName = $_FILES['file']['tmp_name']; 
         $fileDestination = 'pictures/'.$fileName; 
         move_uploaded_file($fileTmpName, $fileDestination);          
         
         $sql="SELECT * FROM student WHERE studentid=? OR studentemail=?;";
         $stmt=mysqli_stmt_init($conn);
         
         if(!mysqli_stmt_prepare($stmt, $sql)){
             echo "SQL statement failed";
         }else{
             mysqli_stmt_bind_param($stmt, "ss", $studentid, $email);
             mysqli_stmt_execute($stmt);
             $result=mysqli_stmt_get_result($stmt);
         }
         
         $resultCheck= mysqli_num_rows($result);
         
         //check if user exist
         if($resultCheck>0){
             
             echo "You have been registered or user name has been taken.";
             exit();
         }else{
             //hash password for security
             $hashedPwd=password_hash($pwd, PASSWORD_DEFAULT);
             //set status to 'Active' for first time registered student
             $sponsorshipStatus='Active';
             
             //insert user data into database
             $sql="INSERT INTO student(studentfullname, studentage, studentusername,studentemail,studentpassword,studentschoolname,studenteducationlevel,studentid,studentimg,sponsorshipStatus)
                  VALUES(?,?,?,?,?,?,?,?,?,?);";
             $stmt=mysqli_stmt_init($conn);
             if(!mysqli_stmt_prepare($stmt, $sql)){
                 echo "SQL statement error";
             }else{
                 mysqli_stmt_bind_param($stmt, "ssssssssss",$fullName,$age,$userName,$email,$hashedPwd,$school,$educationLevel,$studentid,$fileName,$sponsorshipStatus);
                 mysqli_stmt_execute($stmt);
                 $_SESSION['u_name']=$fullName;
                 $_SESSION['u_age']=$age;
                 $_SESSION['u_username']=$userName;
                 $_SESSION['u_email']=$email;
                 $_SESSION['u_schoolname']=$school;
                 $_SESSION['u_educationlevel']=$educationLevel;
                 $_SESSION['u_id']=$studentid;
                 $_SESSION['u_img']=$fileName;
                 $_SESSION['u_sponsorshipStatus']=$sponsorshipStatus;
                 header('location:index.php');
                 exit();
             }
         }
         
     }
 }
 
 
?>



    <div class="container">
      <div class="row">
      <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
      <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
        <h2>Student Registration Form</h2>
      </div>
      <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0"></div>
      </div>
      <div class="row">
        <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
        </div>
        <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label for="reg-student-full-name">Full Name:</label><span class="error">*<?php echo $studentFullNameErr;?></span>
                <input type="text" class="form-control" id="reg_student_full_name" placeholder="Enter Full Name..." name="reg_student_full_name">
            </div>
            
            <div class="form-group">
                <label for="reg-student-age">Student Age:</label><span class="error">*<?php echo $studentAgeErr;?></span>
                <input type="text" class="form-control" id="reg_student_age" name="reg_student_age" placeholder="Enter Your Age...">
            </div>
            
            <div class="form-group">
                <label for="reg-student-username">User Name:</label><span class="error">*<?php echo $studentUsernameErr;?></span>
                <input type="text" class="form-control" id="reg_student_username" name="reg_student_username" placeholder="Enter username...">
            </div>
            
            <div class="form-group">
                <label for="reg-student-email">Student Email:</label><span class="error">*<?php echo $studentEmailErr;?></span>
                <input type="email" class="form-control" id="reg_student_email" placeholder="Enter email..." name="reg_student_email">
            </div>
            
            <div class="form-group">
                <label for="reg-student-password">Password:</label><span class="error">*<?php echo $studentPasswordErr;?></span>
                <input type="password" class="form-control" id="reg_student_password" name="reg_student_password" placeholder="Enter Password...">
            </div>
            
            <div class="form-group">
                <label for="reg-student-password-confirm">Confirm Password:</label><span class="error">*<?php echo $studentConfirmPasswordErr;?></span>
                <input type="password" class="form-control" id="reg_student_password_confirm" name="reg_student_password_confirm" placeholder="Confirm Password...">
            </div>
        
             <div class="form-group">
                <label for="reg-student-school">Student School Name:</label><span class="error">*<?php echo $studentSchoolErr;?></span>
                <input type="text" class="form-control" id="reg_student_school" name="reg_student_school" placeholder="Enter School Name...">
            </div>
        
            <div class="form-group">
                <label for="reg-student-education-level">Student Education Level:</label><span class="error">*<?php echo $studentEducationLevelErr;?></span>
                <input type="text" class="form-control" id="reg_student_education_level" name="reg_student_education_level" placeholder="Enter your education level...">
            </div>
        
            <div class="form-group">
                <label for="reg-student-id">Student ID:</label><span class="error">*<?php echo $studentIDErr;?></span>
                <input type="text" class="form-control" id="reg_student_id" name="reg_student_id" placeholder="Enter Your student ID...">
            </div>
            
            <div class="form-group">
                <label for="reg-student-image">Student Image:</label><span class="error">*<?php echo $studentImgErr;?></span>
                <input type="file" name="file">
            </div>
            
        
            <button type="submit" name="submit" class="btn btn-default">Register</button>
            
            <div class="etc-login-form">
                <p>already have an account? <a href="studentloginform.php">login here</a></p>
            </div>
        </form>
        </div>
        <div class="col-lg-3 col-md-2 col-sm-2 col-xs-0">
        </div>
      </div>
    </div>
    
    <br><br><br><br><br><br><br>
    <?php 
    include "footer.php";
    ?>
    
    </body>
</html>

    
