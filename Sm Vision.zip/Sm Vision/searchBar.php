<div class="container">
    <div class="row">    
        <div class="col-xs-8 col-xs-offset-2">
		  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
		    <div class="input-group">
                <div class="input-group-btn search-panel">
                   <select name="filter" class="form-control" style="width:auto;">
                    	<option value="1" selected>Filter All</option>
                        <option value="2">Student Name</option>
                        <option value="3">Student Age</option>
                        <option value="4">School Name</option>
                        <option value="5">Education Level</option>
                        <option value="6">Student Email</option>
                        <option value="7">Sponsorship Status</option>
                   </select>
                </div>    
                <input type="text" class="form-control" name="searchQuery" placeholder="Search student...">
                <span class="input-group-btn">
                    <button class="btn btn-info" type="submit" name="searchSubmit"><span class="glyphicon glyphicon-search"></span></button>
                </span>
            </div>
          </form>
        </div>
	</div>
</div>

<?php 
if(isset($_POST['searchSubmit'])){
    include 'dbh.php';
        
    $query=mysqli_real_escape_string($conn,$_POST['searchQuery']);
    $selectedFilter=mysqli_real_escape_string($conn,$_POST['filter']);
    
    $sql = "SELECT * FROM STUDENT WHERE (studentfullname LIKE CONCAT('%', ? ,'%')) or (studentage = ?) or
            (studentschoolname LIKE CONCAT('%', ? ,'%')) or (studenteducationlevel LIKE CONCAT('%', ? ,'%')) or
            (studentid LIKE CONCAT('%', ? ,'%')) or (studentemail LIKE CONCAT('%', ? ,'%')) or
            (sponsorshipStatus LIKE CONCAT('%', ? ,'%')) or (studentimg LIKE CONCAT('%', ? ,'%'));";
    
    switch($selectedFilter){
        case 1:
            $selectedFilter = "All";
            break;
        case 2:
            $selectedFilter = "studentfullname";
            $sql = "SELECT * FROM STUDENT WHERE studentfullname LIKE CONCAT('%', ? ,'%');";
            break;
        case 3:
            $selectedFilter = "studentage";
            $sql = "SELECT * FROM STUDENT WHERE studentage LIKE CONCAT('%', ? ,'%');";
            break;
        case 4:
            $selectedFilter = "studentschoolname";
            $sql = "SELECT * FROM STUDENT WHERE studentschoolname LIKE CONCAT('%', ? ,'%');";
            break;
        case 5:
            $selectedFilter = "studenteducationlevel";
            $sql = "SELECT * FROM STUDENT WHERE studenteducationlevel LIKE CONCAT('%', ? ,'%');";
            break;
        case 6:
            $selectedFilter = "studentid";
            $sql = "SELECT * FROM STUDENT WHERE studentid LIKE CONCAT('%', ? ,'%');";
            break;
        case 7:
            $selectedFilter = "studentemail";
            $sql = "SELECT * FROM STUDENT WHERE studentemail LIKE CONCAT('%', ? ,'%');";
            break;
        case 8:
            $selectedFilter = "sponsorshipStatus";
            $sql = "SELECT * FROM STUDENT WHERE sponsorshipStatus LIKE CONCAT('%', ? ,'%');";
            break;
        case 9:
            $selectedFilter = "studentimg";
            $sql = "SELECT * FROM STUDENT WHERE studentimg LIKE CONCAT('%', ? ,'%');";
            break;
    }
    
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        echo "SQL statement failed";
    }else{
        if($selectedFilter != 'All'){
            mysqli_stmt_bind_param($stmt, "s", $query);
            mysqli_stmt_execute($stmt);
            $result=mysqli_stmt_get_result($stmt);
        }else{
            mysqli_stmt_bind_param($stmt, "sisssss", $query, $query, $query, $query, $query, $query, $query);
            mysqli_stmt_execute($stmt);
            $result=mysqli_stmt_get_result($stmt);
        }
    }
    
    
    if($result):
            ?>
             
            <div class="container" style="margin-top:20px; font-family: Calibri Light;">
            <div class="row">
                <table id="table" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th scope="col">Student Name</th>
                      <th scope="col">Age</th>
                      <th scope="col">School Name</th>
                      <th scope="col">Education Level</th>
                      <th scope="col">Student ID</th>
                      <th scope="col">Email</th>
                      <th scope="col">Status</th>
                      <th scope="col">Image</th>
                   
                    </tr>
                  </thead>
            <?php 
            while($student=mysqli_fetch_assoc($result)):
            ?>
            
            <tbody>
              	<tr>
                  <td scope="row"><?php echo $student['studentfullname'] ?></td>
                  <td><?php echo $student['studentage'] ?></td>
                  <td><?php echo $student['studentschoolname']?></td>
                  <td><?php echo $student['studenteducationlevel']?></td>
                  <td><?php echo $student['studentid']?></td>
                  <td><?php echo $student['studentemail']?></td>
                  <?php 
                    $status = $student['sponsorshipStatus']; 
                    if($status == 'Active') {
                        ?><td style="color:green;"><?php echo $student['sponsorshipStatus']?></td><?php 
                    }else{
                        ?><td style="color:red;"><?php echo $student['sponsorshipStatus']?></td><?php 
                    }
                  ?>
                  <td><?php echo $student['studentimg']?></td>
                </tr>
            </tbody>
     		<?php 
            endwhile;
        endif;    
        ?>
            </table>
</div>
</div>
        
        <?php 
}else{
    
 ?>
    <div class="container" style="margin-top:20px; font-family: Calibri Light;">
    <div class="row">
    <table id="table" class="table table-bordered table-hover">
    <thead>
    <tr>
    <th scope="col">Student Name</th>
    <th scope="col">Age</th>
    <th scope="col">School Name</th>
    <th scope="col">Education Level</th>
    <th scope="col">Student ID</th>
    <th scope="col">Email</th>
    <th scope="col">Status</th>
    <th scope="col">Image</th>
    
    </tr>
    </thead>
    <?php
    include 'dbh.php';
    $sql = "SELECT * FROM STUDENT";
    $result = mysqli_query($conn, $sql);
    if($result):
    while($student=mysqli_fetch_assoc($result)):
    ?>
            
            <tbody>
              	<tr>
                  <td scope="row"><?php echo $student['studentfullname'] ?></td>
                  <td><?php echo $student['studentage'] ?></td>
                  <td><?php echo $student['studentschoolname']?></td>
                  <td><?php echo $student['studenteducationlevel']?></td>
                  <td><?php echo $student['studentid']?></td>
                  <td><?php echo $student['studentemail']?></td>
                  <?php 
                    $status = $student['sponsorshipStatus']; 
                    if($status == 'Active') {
                        ?><td style="color:green;"><?php echo $student['sponsorshipStatus']?></td><?php 
                    }else{
                        ?><td style="color:red;"><?php echo $student['sponsorshipStatus']?></td><?php 
                    }
                  ?>
                  <td><?php echo "<img src='pictures/", $student['studentimg'],"' width='125px' height='125px' />";?></td>
                </tr>
            </tbody>
            <?php 
            endwhile;
        endif;    
      ?>
    </table>
</div>
</div>
<?php 
}

  
?>
