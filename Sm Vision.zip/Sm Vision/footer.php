<div class="container-fluid" style="background-color:  #EFECE9; ">
    <div class="row">
        <hr>
        	<div class="col-lg-0 col-md-0 col-sm-0 col-xs-0"></div>
        	<div class="col-lg-6 col-md-6 col-sm-4 col-xs-12">
        		<h5 style="margin-left:35px;"><b>About Us</b></h5>
        		<p style="text-align: justify; margin-left:35px;">SM Vision is an Education Charity Organization that provides educations facilities to the underprivileged
        		 students at Malaysia through public donation. The donation can be done by sponsoring one or more students or 
        		 it can be a common donation to the organization.</p>
        	
        	</div>
        	
        	<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
        		<h5 style="margin-left:35px;"><b>Connect With Us</b></h5>
	        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3" style="padding:0px;">
        		<ul style="list-style: none;">
        			<li>      
		  	          <a  href="https://www.instagram.com/foodliciousssssss/?hl=en"><i class="fa fa-instagram" style="font-size:36px; color:#bc2a8d;"></i></a>
		  	          <br><a href="#">Instagram</a>
        			</li>
        		</ul>
        		</div>
	        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3" style="padding:0px;">
        		<ul style="list-style: none;">
        			<li>      
      					<a href="https://www.tumblr.com/foodliciousssssss"><i class="fa fa-tumblr-square" style="font-size:37px; color: #35465c;"></i></a>
   				        <br><a href="#">Tumblr</a>
        			</li>
        		</ul>
        		</div>
	        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3" style="padding:0px;">
        		<ul style="list-style: none;">
        			<li>      
                    	<a href="https://twitter.com/Foodlicioussss2"><i class="fa fa-twitter" style="font-size:36px; color:#00aced;"></i></a>
			  	        <br><a href="#">Twitter</a>
        			</li>
        		</ul>
        		</div>
	        	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3" style="padding:0px;">
        		<ul style="list-style: none;">
        			<li>      
                    	<a href="https://www.facebook.com/Foodliciousssssss-1067829026713829/"><i class="fa fa-facebook-official" style="font-size:36px; color:#3b5998;"></i></a>
		    	        <br><a href="#">Facebook</a>
        			</li>
        		</ul>
        		</div>
        	</div>
        	
        	<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
        		<h5 style="margin-left: 35px;"><b>Contact Us</b></h5>
	        		<ul style="list-style: none;">
    		    		<li><i class="fa fa-phone"></i> +66(0)53271511</li>
		    		</ul>
		    		<ul style="list-style:none;">
		    			<li><i class="fa fa-envelope"></i> info@smvision.org</li>
		    		</ul>
        	</div>
        	<div class="col-lg-0 col-md-0 col-sm-0 col-xs-0"></div>
        	
    </div>
 	<hr>
    <div class="row">
        <p class="txt-railway footer-copyright" style="text-align:center;"><b>&copy; SM Vision 2019</b></p>
    </div>
</div>






