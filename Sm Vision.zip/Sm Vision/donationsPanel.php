<div class="row donation-panel-position">
    <div class="container">
    	<div class="panel-group">
        	<div class="col-lg-1 col-md-0 col-sm-0 col-xs-0"></div>
        		<div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                        <div class="panel panel-default m-t-30">
                          <div class="panel-heading">
                          	<img class="donation-icon-size" src="pictures/donationIcon.jpg" alt="Donation">
                          	<p class="panel-heading-title"><b>Donate Us</b></p>
                          </div>
                          <div class="panel-body">
                          	<p><b>Be a part of the contributer family<br>to help us grow SM Vision!</b></p>
                          	<p>Your support helps us pave the way to greater success<br>and impact on a national, and international, scale.</p>
                          	<p>Whatever your focus, <b>your investment will be transformative.</b> View Details<br>to see how you can<br>help us!</p>
                          	<a class="btn btn-info m-t-15 m-b-15" href="donateStudentPayment.php">View Details</a>
                          </div>
                        </div>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12"> 
                    <div class="panel panel-default m-t-30">
                        <div class="panel-heading">
                          	<img class="donation-icon2-size" src="pictures/donationIcon2.jpg" alt="Donation">
                        	<p class="panel-heading-title"><b>Sponsor Student</b></p>
                        </div>
                        <div class="panel-body">
                        	<p><b>Higher education is the best ticket out of poverty!</b></p>
                        	<P>Unfortunately, too many of the students who could most benefit from higher education are finding it<br>harder and harder to afford.</P>
                        	<P>This is why <b>We Need You!</b> Your sponsorship not only provide financial support for their educations, but also an investment in their futures.</p>
                        	<p>View details to see how you can sponsor a student!</p>
                          	<a class="btn btn-info m-t-15 m-b-15" href="donateStudent.php">View Details</a>
                        </div>
                    </div>
                </div>
            <div class="col-lg-1 col-md-0 col-sm-0 col-xs-0"></div>
		</div>
    </div>
</div>

<br><br><br><br><br><br><br><br><br>