<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
<body>
	
<div class="row">
	<div class="navbar-wrapper">
        <?php 
            include 'menubar.php';
        ?>
	</div>
</div>
    <?php 
      include 'dbh.php';
    ?>

<div class="row">
<div class="panel-group">
        	<div class="col-lg-3 col-md-3 col-sm-1 col-xs-1"></div>
        		<div class="col-lg-6 col-md-6 col-sm-10 col-xs-10">
                        <div class="panel panel-default m-t-30">
                          <div class="panel-heading">
                          	<img class="donation-icon-size" src="pictures/donationIcon.jpg" alt="Donation">

                          	<p class="panel-heading-title"><b>Donate Us</b></p>
                          </div>
                          <div class="panel-body">
                          <div class="col-lg-2"></div>
                          <table>
                          	<tbody style="font-size:18px;">
                          		<tr>
                          			<td style="float:right;"><b>Student Name &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo ucwords($_COOKIE['name'])?></b></td>
                          		</tr>
                          		<tr>
                          			<td style="float:right;"><b>Age &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $_COOKIE['age']?></b></td>
                          		</tr>
								<tr>
                          			<td style="float:right;"><b>School Name &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo ucwords($_COOKIE['schoolName'])?></b></td>
                          		</tr>
                          		<tr>
                          			<td style="float:right;"><b>Education Level &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo ucwords($_COOKIE['educationLevel'])?></b></td>
                          		</tr>
                          		<tr>
                          			<td style="float:right;"><b>Student ID &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $_COOKIE['studentID']?></b></td>
                          		</tr>
                          		<tr>
                          			<td style="float:right;"><b>Email &nbsp:</b></td>
                          			<td style="text-align:left;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $_COOKIE['email']?></b></td>
                          		</tr>
                          		<tr>
                          			<td style="float:right;"><b>Status &nbsp:</b></td>
                      			    <?php 
                                        $status = $_COOKIE['status']; 
                                        if($status == 'Active') {
                                            ?><td style="text-align:left; color:green;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $_COOKIE['status']?></b></td><?php 
                                        }else{
                                            ?><td style="text-align:left; color:red;"><b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $_COOKIE['status']?></b></td><?php
                                        }
                                      ?>
                          		</tr>
                          	</tbody>
                          </table>
                          <div class="col-lg-2"></div>
                          <?php 
                              $status = $_COOKIE['status'];
                              if($status == 'Active') {
                                  ?><a style="margin-right:90px;" href="donateStudentPayment.php" class="btn btn-info m-t-20 m-b-15">Sponsor</a><?php 
                              }
                          ?>
                          </div>
                        </div>
                </div>
            <div class="col-lg-3 col-md-3 col-sm-1 col-xs-1"></div>
		</div>
</div>

<div class="row" style="padding-top:70px;">    
<?php 
    include "footer.php";
?>
</div>
</body>
</html>



<?php 
    $studentimg = $_COOKIE['image'];
    $name = $_COOKIE['name'];
    $age = $_COOKIE['age'];
    $schoolName = $_COOKIE['schoolName'];
    $educationLevel = $_COOKIE['educationLevel'];
    $studentID = $_COOKIE['studentID'];
    $email = $_COOKIE['email'];
    $status = $_COOKIE['status'];
    
?>