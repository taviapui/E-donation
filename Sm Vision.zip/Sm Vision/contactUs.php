<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'
	?>
	<body>
		
			
		  
		<div class="row">
			<div class="navbar-wrapper">
              <?php 
                include 'menubar.php';
            ?>
			</div>
		</div>
   
	
	
	<div class="row">
    	<div class="col-lg-3 col-md-3 col-sm-2 col-xs-1"></div>
    	<div class="col-lg-3 col-md-4 col-sm-4 col-xs-5">
        	<h3 class="title-font" style="font-size:30px; text-align:left;">CONTACT US</h3>
    	</div>
        <div class="col-lg-6 col-md-5 col-sm-6 col-xs-6"></div>
	</div>
	
	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-1"></div>
    	<div class="col-lg-6 col-md-6 col-sm-8 col-xs-10" style="border:1px solid #cccccc; margin-bottom: 100px; padding-bottom:10px;  padding-top:10px;">
          	<form method="POST" action="contactformResult.php"> 
            	<div class="form-group">
            		<label for="name">Name:</label> 
            		<input type="text"  class="form-control" name="name"  placeholder="Enter your full name...">  
           		</div>
        		<div class="form-group"> 
          			<label for="email">Email:</label>  
            		<input type="email" class="form-control" name="email" placeholder="Enter your email address...">
        	 	</div>
        		<div class="form-group">
            		<label for="subject">SUBJECT</label>
             		<input type="text" class="form-control" name="subject" placeholder="Enter subject (optional)...">
             	</div>
             	<div class="form-group">
             		<label for="subject">MESSAGE</label> 
            		<textarea name="message" class="form-control" placeholder="Write your message here..." style="height:200px; resize:none; "></textarea>
            	</div>
            	<button type="submit" name="submit" class="btn btn-default" style="float:right;">Submit</button>
        	</form>
    	</div>
    	<div class="col-lg-3 col-md-3 col-sm-2 col-xs-1"></div>
	</div>



<?php 
    include "footer.php";
?>   

		
	</body>
</html>
		