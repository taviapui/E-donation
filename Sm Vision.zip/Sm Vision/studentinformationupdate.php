<!DOCTYPE html>
<html>
	<head>
	  <?php 
        include 'header.php';	  
	  ?>
	</head>
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
          <?php 
            include 'menubar.php';
        ?>
		</div>
	</div>
	
<?php 
//update user information
include 'dbh.php';

if(isset($_POST['update'])){
    
    $name = mysqli_real_escape_string($conn, $_POST['update_name']);
    $age = mysqli_real_escape_string($conn,$_POST['update_age']);
    $username = mysqli_real_escape_string($conn, $_POST['update_username']);
    $email = mysqli_real_escape_string($conn, $_POST['update_email']);
    $schoolname = mysqli_real_escape_string($conn,$_POST['update_schoolname']);
    $educationlevel = mysqli_real_escape_string($conn, $_POST['update_educationlevel']);
    $id = mysqli_real_escape_string($conn, $_POST['update_id']);
    $pwd = mysqli_real_escape_string($conn, $_POST['update_password']);
    $cpwd=$_POST['update_confirmpassword'];
    
    if(empty($name) || empty($age) || empty($username) || empty($email) || empty($schoolname) || empty($educationlevel) || empty($id)){
        echo "Update failed! Your input is empty";
        exit();
        
    }elseif(!preg_match("/^[a-zA-Z ]*$/", $name)){
        echo "Your Name must contains only letters and white space";
        exit();
        
    }elseif(!preg_match("/^[0-9]{1,5}$/", $age)){
        echo "Invalid Age";
        exit();
           
    }elseif(!preg_match("/^[a-zA-Z0-9]*$/", $username)){
        echo "Your username must contains only letters and/or numbers";
        exit();
        
    }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo "Invalid email format";
        exit();
   
    }elseif(!preg_match("/^[a-zA-Z ]*$/", $schoolname)){
        echo "Your School Name must contains only letters and white space";
        exit();
        
    }elseif(!preg_match("/^[a-zA-Z ]*$/", $educationlevel)){
        echo "Your specify your education level";
        exit();
        
    }elseif(!preg_match("/^[a-zA-Z0-9]*$/", $id)){
        echo "Your student id must contains only letters and/or numbers";
        exit();
        
    }
    
    
    //**
    $sql="SELECT * FROM student WHERE studentusername=?;";
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt,$sql)){
        echo "SQL statement failed";
    }else{
        mysqli_stmt_bind_param($stmt, "s" ,$username);
        mysqli_stmt_execute($stmt);
        $result=mysqli_stmt_get_result($stmt);
    }
    
    $resultCheck= mysqli_num_rows($result);
    
    //check if user exist
    if($resultCheck>1){
        echo "User name has been taken.";
        exit();
    }
    
    if(!empty($pwd)){
        
        $hashedPwd=password_hash($pwd, PASSWORD_DEFAULT);
        $sql="UPDATE student SET studentfullname=?,studentage=?,studentusername=?,studentemail=?,studentpassword=?,
          studentschoolname=?,studenteducationlevel=?,studentid=? WHERE studentid='$_POST[id]';";
        
        $stmt=mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            echo "SQL error";
        }else{
            mysqli_stmt_bind_param($stmt, "sissssss",$name,$age,$username,$email,$hashedPwd,$schoolname,$educationlevel,$id);
            mysqli_stmt_execute($stmt);
        }
    }else{
        $sql="UPDATE student SET studentfullname=?,studentage=?,studentusername=?,studentemail=?,
          studentschoolname=?,studenteducationlevel=?,studentid=? WHERE studentid='$_POST[id]';";
        
        $stmt=mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt,$sql)){
            echo "SQL error";
        }else{
            mysqli_stmt_bind_param($stmt, "sisssss",$name,$age,$username,$email,$schoolname,$educationlevel,$id);
            mysqli_stmt_execute($stmt);
        }
    }
  
         
    if(mysqli_stmt_prepare($stmt,$sql)){
        
        $_SESSION['u_newid']=$id;
        $_SESSION['u_newname']=$name;
        $_SESSION['u_newage']=$age;
        $_SESSION['u_newusername']=$username;
        $_SESSION['u_newemail']=$email;
        $_SESSION['u_newschoolname']=$schoolname;
        $_SESSION['u_neweducationlevel']=$educationlevel;
        
        echo "<h4 style='text-align:left; padding-left:20px; color:green;'> Update Successful!</h4>";
       ?>
       	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-0">
		</div>
		
		<div class="col-lg-6 col-md-6 col-sm-8 col-xs-12">
        <table style="border:1px solid #cccccc;" class="table table-user-information">
        <tbody>
        <tr>
        <th style="font-size:18px;" >Updated Personal Information</th>
        <th></th>
        </tr>
        
        <tr>
        	<td>Full Name:</td>
        	<td><?php echo $_SESSION['u_newname']?></td>
        </tr>
            
        <tr>
        	<td>Student Age:</td>
        	<td><?php echo $_SESSION['u_newage']?></td>
        </tr>
        
        <tr>
        	<td>User Name:</td>
            <td><?php echo $_SESSION['u_newusername']?></td>
        </tr>
        
        <tr>
        	<td>Email:</td>
        	<td><?php echo $_SESSION['u_newemail']?></td>
        </tr>
                
        <tr>
            <td>School Name:</td>
            <td><?php echo $_SESSION['u_newschoolname']?></td>
        </tr>
        
        <tr>
            <td>Education Level:</td>
            <td><?php echo $_SESSION['u_neweducationlevel']?></td>
        </tr>
                        
        <tr>
            <td>Student ID:</td>
            <td><?php echo $_SESSION['u_newid']?></td>
        </tr>

      </tbody>
      </table>
      
      <form action="index.php">
		    <button type="submit" name="backtohome" style="float:right; margin-top:5px;" class="btn btn-default">DONE</button>
	  </form>
       
      
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-0">
		</div>
	    </div>
        </div>
       <?php 
    }else{
        echo "Update failed";
    }
}

?>




   <div class="row" style="padding-top:100px;">    
    <?php 
    include "footer.php";
    ?>
    </div>

</body>
</html>