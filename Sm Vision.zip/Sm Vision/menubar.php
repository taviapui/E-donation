
<nav class="navbar navbar navbar-default navbar-static-top">        
    <div class="container-fluid">
        <div id="navbar" class="navbar-collapse collapse">
            <a class="navbar-brand" href="index.php">SM Vision</a>
	        <img class="school-logo-size" src="pictures/sunwayLogo.png" alt="Donation">
            <ul class="nav navbar-nav" style="float:right;  padding-top:14px;padding-right: 35px;">                       
                <li>
                    <a href="index.php" target="_self">HOME</a> 
                </li>
                <li>
                	<a href="aboutUs.php" target="_self">About Us</a>
                <li>
                <li class="dropdown"> <a class="dropdown-toggle" aria-expanded="false" contenteditable="false"
                    href="#" data-toggle="dropdown" >Donate<span class="caret"></span> </a>
                    <ul class="dropdown-menu">
                        <li><a href="donateStudentPayment.php">SM Vision</a></li>
                        <li><a href="donateStudent.php">Students</a></li>
                    </ul>
                </li>
                <li>
                    <a href="contactUs.php" target="_self">Contact Us</a>
                </li>
                <li>
                <?php 
                if(isset($_SESSION['u_id'])){
                   echo "<li style=padding-top:15px;>Hello, ".$_SESSION['u_name']."</li>"; 
                }else if(isset($_SESSION['d_username'])){
                    echo "<li style=padding-top:15px;>Hello, ".$_SESSION['d_name']."</li>";
                }
                ?>
                </li>
                <li class="dropdown"> <a class="dropdown-toggle" aria-expanded="false" contenteditable="false"
                    href="#" data-toggle="dropdown" ><span class="glyphicon glyphicon-user"></span></a>
                        <?php 
    					if(isset($_SESSION['u_id']) || isset($_SESSION['u_newid'])){
    					    ?>
    					    <ul class="dropdown-menu" style="left:-67px; text-align:right; min-width:110px;">
                            	<li><a href="studentLoginForm.php">My Profile</a></li>
                            	<li><a href="logout.php"><i class="fa fa-power-off"></i>&nbsp&nbspLog Out</a>
                            </ul>
    					    <?php 
    					}else if(isset($_SESSION['d_username'])){
    					    ?>
    					    <ul class="dropdown-menu" style="left:-67px; text-align:right; min-width:110px;">
                            	<li><a href="donorLoginForm.php">My Profile</a></li>
                            	<li><a href="logout.php"><i class="fa fa-power-off"></i>&nbsp&nbspLog Out</a>
                            </ul>
    					    <?php 
    					}else{
    					    ?>
	                        <ul class="dropdown-menu" style="left:-80px; text-align:right; min-width:110px;">
                      	 	   <li><a href="donorLoginForm.php">Donor Log In</a></li>
                            	<li><a href="studentLoginForm.php">Student Log In</a></li>
                        	</ul>
    					    <?php 
    					}
    					?> 
                </li>
            </ul> 
        </div>   
    </div>
</nav>