<!-- <?php
    //include  'dbh.php'; 
?> -->

<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php';
	?>
	
<body style="min-height:200px; overflow-x: hidden;">
			
<!-- navigation bar -->		  
	<div class="row">
		<div class="navbar-wrapper">
          <?php 
            include 'menubar.php';
          ?>
		</div>
	</div>
<!-- /navigation bar -->	

<!-- slides show -->
	<div class="row">
    	<?php 
	      include 'carousel.php';
    	?>
	</div>
	
<!-- slides show -->

<!-- Donation Panels -->
	<?php 
	  include 'donationsPanel.php'; 
	?>
<!-- Donation Panels -->

<!-- Footer -->
	<?php 
	   include 'footer.php';
	?>
<!-- Footer -->





	
     
</body>
</html>