<!DOCTYPE html>
<html>
	<?php 
	   include 'header.php'; 
	?>
	
	<body>
		
	<div class="row">
		<div class="navbar-wrapper">
            <?php 
                include 'navigation.php';
            ?>
		</div>
	</div>

	<div class="container" style="font-family: Calibri Light;">
	  <div class="row">
	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-4 col-md-8 col-sm-8 col-xs-12">
  	  	<h2 style="text-align:center;"><b> - Our Mission - </b></h2>
  	  </div>
  	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  
	  <div class="row">
		<div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3 style="text-align:justify; font-size: 22px;">The SM Vision Foundation inspires and empowers students from low-income families to
			    enroll in and graduate from postsecondary institutions of higher education, by providing the tools, 
			    knowledge, and financial resources essential for success.</h3>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>
	  
	  <div class="row">
	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
  	  <div class="col-lg-4 col-md-8 col-sm-8 col-xs-12">
  	  	<h2 style="text-align:center;"><b> About Us </b></h2>
  	  </div>
  	  <div class="col-lg-4 col-md-2 col-sm-2 col-xs-0"></div>
	  </div>
	  
	   <div class="row">
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
		<div class="col-lg-10 col-md-8 col-sm-8 col-xs-12">
			<h3 style="text-align:justify; font-size: 22px">SM Vision is an Education Charity Organization that provides educations 
			   facilities to the underprivileged students at Malaysia through public donation. The donation can be done 
			   by sponsoring one or more students or it can be a common donation to the organization. Research shows that 
			   work can take up more than 15 hours per week and becomes an impediment to academic success. For many students 
			   the stresses of working make it difficult for them to graduate on time, or graduate with the high grades they 
			   have the potential to achieve. For other students, the work/study life is unsustainable, and they discontinue 
			   their studies all together. Hence, By providing access to education through scholarships is increasingly important, as you assist students in realizing their dreams 
			   and reaching their fullest potentials.</h3>
		</div>
		<div class="col-lg-1 col-md-2 col-sm-2 col-xs-0">
		</div>
	  </div>
	</div>
	
	<br><br><br><br><br><br><br>
	<?php 
    include "footer.php";
    ?>
	
	</body>
</html>

	
