<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smvision"; 

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    echo 'failed';
    die("Connection failed: " . mysqli_connect_error());
}

?>
